use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::io::{self, BufRead, BufReader, Write};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader as AsyncBufReader};
use tokio::process::{ChildStdin, ChildStdout};
// -------------------------------------------------------------------------------------------------
// MCP Protocol Types
#[derive(Debug, Serialize, Deserialize)]
struct JsonRpcRequest {
    jsonrpc: String,
    id: Option<Value>,
    method: String,
    params: Option<Value>,
}
// -------------------------------------------------------------------------------------------------
#[derive(Debug, Serialize, Deserialize)]
struct JsonRpcResponse {
    jsonrpc: String,
    id: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    result: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    error: Option<JsonRpcError>,
}
// -------------------------------------------------------------------------------------------------
#[derive(Debug, Serialize, Deserialize)]
struct JsonRpcError {
    code: i32,
    message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    data: Option<Value>,
}
// -------------------------------------------------------------------------------------------------
#[derive(Debug, Serialize, Deserialize)]
struct Tool {
    name: String,
    description: String,
    #[serde(rename = "inputSchema")]
    input_schema: Value,
}
// -------------------------------------------------------------------------------------------------
#[derive(Debug, Serialize, Deserialize)]
struct Resource {
    uri: String,
    name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    description: Option<String>,
    #[serde(rename = "mimeType", skip_serializing_if = "Option::is_none")]
    mime_type: Option<String>,
}
// -------------------------------------------------------------------------------------------------
pub struct McpServer {
    tools: HashMap<String, Tool>,
    resources: HashMap<String, Resource>,
}
// -------------------------------------------------------------------------------------------------
impl McpServer {
    pub fn new() -> Self {
        let mut server = Self {
            tools: HashMap::new(),
            resources: HashMap::new(),
        };
        // -----------------------------------------------------------------------------------------
        // Add some example tools
        server.add_tool(Tool {
            name: "echo".to_string(),
            description: "Echo back the input text".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Text to echo back"
                    }
                },
                "required": ["text"]
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "current_time".to_string(),
            description: "Get the current time".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "list_datasets".to_string(),
            description: "Get the data products datasets".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_owner".to_string(),
            description: "Get the owner of the data product (CDMC 2)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_classification".to_string(),
            description: "Get the classification of the data product (CDMC 6)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_policy".to_string(),
            description: "Get the associated policy to the data product (CDMC 7)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_purpose".to_string(),
            description: "Get the associated data sharing agreements to the data product (CDMC 8)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_security_controls".to_string(),
            description: "Get the security controls of the data product (CDMC 9)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        server.add_tool(Tool {
            name: "get_lineage".to_string(),
            description: "Get the lineage of the data product (CDMC 13)".to_string(),
            input_schema: json!({
                "type": "object",
                "properties": {}
            }),
        });
        // -----------------------------------------------------------------------------------------
        // DPROD
        server.add_resource(Resource {
            uri: "https://ekgf.github.io/dprod".to_string(),
            name: "DPROD ontology".to_string(),
            description: Some("DPROD extends DCAT to enable publishers to describe Data Products and data services in a decentralized way.".to_string()),
            mime_type: Some("text/plain".to_string()),
        });
        // -----------------------------------------------------------------------------------------
        // DCAT
        server.add_resource(Resource {
            uri: "http://www.w3.org/ns/dcat".to_string(),
            name: "DCAT ontology".to_string(),
            description: Some("DCAT is an RDF vocabulary designed to facilitate interoperability between data catalogs published on the Web.".to_string()),
            mime_type: Some("text/plain".to_string()),
        });
        // -----------------------------------------------------------------------------------------
        // PROV
        server.add_resource(Resource {
            uri: "http://www.w3.org/ns/prov".to_string(),
            name: "PROV ontology".to_string(),
            description: Some("The PROV Family of Documents defines a model, corresponding serializations and other supporting definitions to enable the inter-operable interchange of provenance information in heterogeneous environments such as the Web.".to_string()),
            mime_type: Some("text/plain".to_string()),
        });
        // -----------------------------------------------------------------------------------------
        // ODRL
        server.add_resource(Resource {
            uri: "http://www.w3.org/ns/odrl/2/".to_string(),
            name: "ODRL Version 2.2".to_string(),
            description: Some("The ODRL Vocabulary and Expression defines a set of concepts and terms (the vocabulary) and encoding mechanism (the expression) for permissions and obligations statements describing digital content usage based on the ODRL Information Model.".to_string()),
            mime_type: Some("text/plain".to_string()),
        });

        server
    }
    // ---------------------------------------------------------------------------------------------
    pub fn add_tool(&mut self, tool: Tool) {
        self.tools.insert(tool.name.clone(), tool);
    }
    // ---------------------------------------------------------------------------------------------
    pub fn add_resource(&mut self, resource: Resource) {
        self.resources.insert(resource.uri.clone(), resource);
    }
    // ---------------------------------------------------------------------------------------------
    pub async fn handle_request(&self, request: JsonRpcRequest) -> JsonRpcResponse {
        match request.method.as_str() {
            "initialize" => self.handle_initialize(request.id),
            "tools/list" => self.handle_tools_list(request.id),
            "tools/call" => self.handle_tools_call(request.id, request.params).await,
            "resources/list" => self.handle_resources_list(request.id),
            "resources/read" => self.handle_resources_read(request.id, request.params).await,
            _ => JsonRpcResponse {
                jsonrpc: "2.0".to_string(),
                id: request.id,
                result: None,
                error: Some(JsonRpcError {
                    code: -32601,
                    message: "Method not found".to_string(),
                    data: None,
                }),
            },
        }
    }
    // ---------------------------------------------------------------------------------------------
    fn handle_initialize(&self, id: Option<Value>) -> JsonRpcResponse {
        JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            id,
            result: Some(json!({
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {},
                    "resources": {}
                },
                "serverInfo": {
                    "name": "rust-mcp-server",
                    "version": "1.0.0"
                }
            })),
            error: None,
        }
    }
    // ---------------------------------------------------------------------------------------------
    fn handle_tools_list(&self, id: Option<Value>) -> JsonRpcResponse {
        let tools: Vec<&Tool> = self.tools.values().collect();
        JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            id,
            result: Some(json!({
                "tools": tools
            })),
            error: None,
        }
    }
    // ---------------------------------------------------------------------------------------------
    async fn handle_tools_call(&self, id: Option<Value>, params: Option<Value>) -> JsonRpcResponse {
        if let Some(params) = params {
            if let Ok(call_params) = serde_json::from_value::<Value>(params) {
                let tool_name = call_params.get("name").and_then(|v| v.as_str());
                let arguments = call_params.get("arguments");

                if let Some(tool_name) = tool_name {
                    return match tool_name {
                        "echo" => {
                            let text = arguments
                                .and_then(|args| args.get("text"))
                                .and_then(|v| v.as_str())
                                .unwrap_or("No text provided");

                            JsonRpcResponse {
                                jsonrpc: "2.0".to_string(),
                                id,
                                result: Some(json!({
                                    "content": [{
                                        "type": "text",
                                        "text": format!("Echo: {}", text)
                                    }]
                                })),
                                error: None,
                            }
                        },
                        "current_time" => {
                            let now = chrono::Utc::now();
                            JsonRpcResponse {
                                jsonrpc: "2.0".to_string(),
                                id,
                                result: Some(json!({
                                    "content": [{
                                        "type": "text",
                                        "text": format!("Current time: {}", now.format("%Y-%m-%d %H:%M:%S UTC"))
                                    }]
                                })),
                                error: None,
                            }
                        },
                        _ => JsonRpcResponse {
                            jsonrpc: "2.0".to_string(),
                            id,
                            result: None,
                            error: Some(JsonRpcError {
                                code: -32602,
                                message: format!("Unknown tool: {}", tool_name),
                                data: None,
                            }),
                        }
                    };
                }
            }
        }

        JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            id,
            result: None,
            error: Some(JsonRpcError {
                code: -32602,
                message: "Invalid parameters".to_string(),
                data: None,
            }),
        }
    }
    // ---------------------------------------------------------------------------------------------
    fn handle_resources_list(&self, id: Option<Value>) -> JsonRpcResponse {
        let resources: Vec<&Resource> = self.resources.values().collect();
        JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            id,
            result: Some(json!({
                "resources": resources
            })),
            error: None,
        }
    }
    // ---------------------------------------------------------------------------------------------
    async fn handle_resources_read(&self, id: Option<Value>, params: Option<Value>) -> JsonRpcResponse {
        if let Some(params) = params {
            if let Ok(read_params) = serde_json::from_value::<Value>(params) {
                let uri = read_params.get("uri").and_then(|v| v.as_str());

                if let Some(uri) = uri {
                    if self.resources.contains_key(uri) {
                        // In a real implementation, you'd read the actual resource
                        return JsonRpcResponse {
                            jsonrpc: "2.0".to_string(),
                            id,
                            result: Some(json!({
                                "contents": [{
                                    "uri": uri,
                                    "mimeType": "text/plain",
                                    "text": "This is example content from the resource."
                                }]
                            })),
                            error: None,
                        };
                    }
                }
            }
        }
        // ---------------------------------------------------------------------------------------------
        JsonRpcResponse {
            jsonrpc: "2.0".to_string(),
            id,
            result: None,
            error: Some(JsonRpcError {
                code: -32602,
                message: "Invalid parameters or resource not found".to_string(),
                data: None,
            }),
        }
    }
    // ---------------------------------------------------------------------------------------------
    pub async fn run(&self) -> io::Result<()> {
        let stdin = io::stdin();
        let mut stdout = io::stdout();

        for line in stdin.lock().lines() {
            let line = line?;
            if line.trim().is_empty() {
                continue;
            }

            match serde_json::from_str::<JsonRpcRequest>(&line) {
                Ok(request) => {
                    let response = self.handle_request(request).await;
                    let response_json = serde_json::to_string(&response)?;
                    writeln!(stdout, "{}", response_json)?;
                    stdout.flush()?;
                }
                Err(e) => {
                    let error_response = JsonRpcResponse {
                        jsonrpc: "2.0".to_string(),
                        id: None,
                        result: None,
                        error: Some(JsonRpcError {
                            code: -32700,
                            message: format!("Parse error: {}", e),
                            data: None,
                        }),
                    };
                    let response_json = serde_json::to_string(&error_response)?;
                    writeln!(stdout, "{}", response_json)?;
                    stdout.flush()?;
                }
            }
        }

        Ok(())
    }
}
// -------------------------------------------------------------------------------------------------
#[tokio::main]
async fn main() -> io::Result<()> {
    let server = McpServer::new();
    server.run().await
}
// -------------------------------------------------------------------------------------------------