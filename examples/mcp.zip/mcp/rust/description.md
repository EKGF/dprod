# How to Communicate with the MCP Server

## 1. Manual Testing via Command Line

First, build and run the server:
```bash
cargo build --release
./target/release/your-mcp-server
```

Then send JSON-RPC messages via stdin. Each message should be on a single line:

### Initialize the server:
```json
{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "test-client", "version": "1.0.0"}}}
```

### List available tools:
```json
{"jsonrpc": "2.0", "id": 2, "method": "tools/list"}
```

### Call the echo tool:
```json
{"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "echo", "arguments": {"text": "Hello World!"}}}
```

### Call the current_time tool:
```json
{"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "current_time", "arguments": {}}}
```

### TODO in detail, call the non-sample toolS
```json
{"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "list_datasets", "arguments": {}}}

{"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {"name": "get_owner", "arguments": {}}}

{"jsonrpc": "2.0", "id": 6, "method": "tools/call", "params": {"name": "get_classification", "arguments": {}}}

{"jsonrpc": "2.0", "id": 7, "method": "tools/call", "params": {"name": get_policy", "arguments": {}}}
  
{"jsonrpc": "2.0", "id": 8, "method": "tools/call", "params": {"name": get_purpose", "arguments": {}}}
  
{"jsonrpc": "2.0", "id": 9, "method": "tools/call", "params": {"name": "get_security_controls", "arguments": {}}}

{"jsonrpc": "2.0", "id": 10, "method": "tools/call", "params": {"name": "get_lineage", "arguments": {}}}
```
### List resources:
```json
{"jsonrpc": "2.0", "id": 11, "method": "resources/list"}
```

### Read a resource:
```json
{"jsonrpc": "2.0", "id": 12, "method": "resources/read", "params": {"uri": "file:///example.txt"}}
```

## 2. Using a Shell Script for Testing

Create a test script `test_mcp.sh`:

```bash
#!/bin/bash

# Build the server
cargo build --release

# Start the server and send test commands
{
  echo '{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "test-client", "version": "1.0.0"}}}'
  sleep 0.1
  echo '{"jsonrpc": "2.0", "id": 2, "method": "tools/list"}'
  sleep 0.1
  echo '{"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "echo", "arguments": {"text": "Hello from shell!"}}}'
  sleep 0.1
  echo '{"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "current_time", "arguments": {}}}'
} | ./target/release/your-mcp-server
```

## 3. Python Client Example

Create a Python client to interact with the server:

```python
import json
import subprocess
import threading
import queue
import time

class McpClient:
    def __init__(self, server_path):
        self.process = subprocess.Popen(
            [server_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1
        )
        self.request_id = 0
        self.response_queue = queue.Queue()
        
        # Start reader thread
        self.reader_thread = threading.Thread(target=self._read_responses)
        self.reader_thread.daemon = True
        self.reader_thread.start()
    
    def _read_responses(self):
        for line in iter(self.process.stdout.readline, ''):
            if line.strip():
                try:
                    response = json.loads(line.strip())
                    self.response_queue.put(response)
                except json.JSONDecodeError as e:
                    print(f"Failed to parse response: {e}")
    
    def send_request(self, method, params=None):
        self.request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method
        }
        if params:
            request["params"] = params
        
        request_json = json.dumps(request) + "\n"
        self.process.stdin.write(request_json)
        self.process.stdin.flush()
        
        # Wait for response
        timeout = 5
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = self.response_queue.get(timeout=0.1)
                if response.get("id") == self.request_id:
                    return response
                else:
                    # Put it back if it's not our response
                    self.response_queue.put(response)
            except queue.Empty:
                continue
        
        raise TimeoutError("No response received within timeout")
    
    def close(self):
        self.process.terminate()
        self.process.wait()

# Usage example
if __name__ == "__main__":
    client = McpClient("./target/release/your-mcp-server")
    
    try:
        # Initialize
        response = client.send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "python-client", "version": "1.0.0"}
        })
        print("Initialize:", json.dumps(response, indent=2))
        
        # List tools
        response = client.send_request("tools/list")
        print("Tools:", json.dumps(response, indent=2))
        
        # Call echo tool
        response = client.send_request("tools/call", {
            "name": "echo",
            "arguments": {"text": "Hello from Python!"}
        })
        print("Echo:", json.dumps(response, indent=2))
        
        # Call current_time tool
        response = client.send_request("tools/call", {
            "name": "current_time",
            "arguments": {}
        })
        print("Time:", json.dumps(response, indent=2))
        
    finally:
        client.close()
```

## 4. Node.js Client Example

```javascript
const { spawn } = require('child_process');
const readline = require('readline');

class McpClient {
    constructor(serverPath) {
        this.process = spawn(serverPath);
        this.requestId = 0;
        this.pendingRequests = new Map();
        
        // Set up readline for stdout
        const rl = readline.createInterface({
            input: this.process.stdout,
            crlfDelay: Infinity
        });
        
        rl.on('line', (line) => {
            if (line.trim()) {
                try {
                    const response = JSON.parse(line);
                    const promise = this.pendingRequests.get(response.id);
                    if (promise) {
                        this.pendingRequests.delete(response.id);
                        promise.resolve(response);
                    }
                } catch (e) {
                    console.error('Failed to parse response:', e);
                }
            }
        });
    }
    
    async sendRequest(method, params = null) {
        this.requestId++;
        const request = {
            jsonrpc: "2.0",
            id: this.requestId,
            method: method
        };
        
        if (params) {
            request.params = params;
        }
        
        return new Promise((resolve, reject) => {
            this.pendingRequests.set(this.requestId, { resolve, reject });
            
            this.process.stdin.write(JSON.stringify(request) + '\n');
            
            // Timeout after 5 seconds
            setTimeout(() => {
                if (this.pendingRequests.has(this.requestId)) {
                    this.pendingRequests.delete(this.requestId);
                    reject(new Error('Request timeout'));
                }
            }, 5000);
        });
    }
    
    close() {
        this.process.kill();
    }
}

// Usage
async function main() {
    const client = new McpClient('./target/release/your-mcp-server');
    
    try {
        // Initialize
        const initResponse = await client.sendRequest('initialize', {
            protocolVersion: '2024-11-05',
            capabilities: {},
            clientInfo: { name: 'node-client', version: '1.0.0' }
        });
        console.log('Initialize:', JSON.stringify(initResponse, null, 2));
        
        // List tools
        const toolsResponse = await client.sendRequest('tools/list');
        console.log('Tools:', JSON.stringify(toolsResponse, null, 2));
        
        // Call echo tool
        const echoResponse = await client.sendRequest('tools/call', {
            name: 'echo',
            arguments: { text: 'Hello from Node.js!' }
        });
        console.log('Echo:', JSON.stringify(echoResponse, null, 2));
        
    } catch (error) {
        console.error('Error:', error);
    } finally {
        client.close();
    }
}

main();
```

## 5. Integration with MCP Clients

To use with actual MCP clients like Claude Desktop, you need to configure them to use your server. For Claude Desktop, add to your configuration:

```json
{
  "mcpServers": {
    "rust-server": {
      "command": "/path/to/your/target/release/your-mcp-server",
      "args": []
    }
  }
}
```

## Message Flow

1. **Initialize**: Client sends initialize request
2. **Capabilities Exchange**: Server responds with supported capabilities
3. **Tool/Resource Operations**: Client can list and use tools/resources
4. **Bidirectional Communication**: Server can also send notifications to client

All communication follows the JSON-RPC 2.0 specification with each message on a separate line.